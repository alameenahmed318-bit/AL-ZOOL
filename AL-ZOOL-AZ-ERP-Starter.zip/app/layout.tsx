import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AL-ZOOL AZ ERP",
  description: "منصة إدارة الأعمال متعددة الشركات",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
