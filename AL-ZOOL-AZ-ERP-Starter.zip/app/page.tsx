import { Activity, Bot, Building2, FileText, Package, ReceiptText, ShieldCheck, Users, Wallet } from "lucide-react";

const metrics = [
  { label: "إجمالي المبيعات", value: "24,500", suffix: "د.إ", icon: Activity },
  { label: "المصروفات", value: "8,200", suffix: "د.إ", icon: Wallet },
  { label: "الفرق الحسابي", value: "16,300", suffix: "د.إ", icon: ReceiptText },
  { label: "فواتير معلقة", value: "7", suffix: "فاتورة", icon: FileText },
];

const modules = [
  { name: "المبيعات", description: "متابعة عمليات البيع", icon: ReceiptText },
  { name: "العملاء", description: "ملفات العملاء والموردين", icon: Users },
  { name: "المخزون", description: "الأصناف والكميات", icon: Package },
  { name: "الفواتير", description: "المدفوع والمتأخر", icon: FileText },
];

export default function Home() {
  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">AZ</div><div><strong>AL-ZOOL</strong><small>AZ ERP · BUSINESS</small></div></div>
        <div className="workspace"><Building2 size={19}/><div><strong>مساحة العمل التجريبية</strong><small>Demo workspace</small></div></div>
        <div className="nav-title">القائمة الرئيسية</div>
        <a className="nav active" href="#overview"><Activity size={18}/> لوحة التحكم</a>
        <a className="nav" href="#modules"><ReceiptText size={18}/> المبيعات والفواتير</a>
        <a className="nav" href="#modules"><Users size={18}/> العملاء</a>
        <a className="nav" href="#modules"><Package size={18}/> المخزون</a>
        <a className="nav" href="#assistant"><Bot size={18}/> مساعد AI</a>
        <div className="sidebar-foot"><ShieldCheck size={17}/><span>بيانات تجريبية فقط</span></div>
      </aside>

      <section className="content" id="overview">
        <header className="topbar">
          <div><p className="eyebrow">إدارة الأعمال بذكاء</p><h1>لوحة التحكم</h1><p className="muted">مرحبًا بك في نظام AL-ZOOL AZ ERP</p></div>
          <div className="avatar">AZ</div>
        </header>

        <div className="notice"><span className="notice-dot"/> نسخة أولية — الأرقام أدناه افتراضية وليست بيانات محاسبية حقيقية.</div>

        <section className="metrics">
          {metrics.map(({label, value, suffix, icon: Icon}) => (
            <article className="metric" key={label}>
              <div className="metric-top"><span>{label}</span><span className="icon-wrap"><Icon size={19}/></span></div>
              <div className="metric-value">{value}<small>{suffix}</small></div>
              <div className="metric-foot">بيانات توضيحية</div>
            </article>
          ))}
        </section>

        <section className="section" id="modules">
          <div className="section-heading"><div><h2>وحدات النظام</h2><p className="muted">ابدأ بالوحدات الأساسية ثم وسّع النظام حسب نشاطك.</p></div><span className="tag">المرحلة الأولى</span></div>
          <div className="module-grid">
            {modules.map(({name, description, icon: Icon}) => (
              <article className="module" key={name}><span className="module-icon"><Icon size={21}/></span><div><h3>{name}</h3><p>{description}</p></div><span className="arrow">←</span></article>
            ))}
          </div>
        </section>

        <section className="assistant" id="assistant">
          <div className="assistant-head"><span className="bot-icon"><Bot size={23}/></span><div><h2>مساعد الزول AI</h2><p>واجهة تمهيدية لمساعد ذكي</p></div><span className="demo-pill">قيد التجهيز</span></div>
          <div className="chat-bubble"><strong>المساعد:</strong> أهلًا بك! في النسخة المتصلة سأساعدك على تحليل بيانات شركتك والإجابة عن أسئلة مثل: «كم بلغت المبيعات هذا الشهر؟».</div>
          <form action="#assistant" className="chat-form">
            <input aria-label="رسالة المساعد" placeholder="اكتب أمرًا للتجربة، مثل: لخص المبيعات..." disabled />
            <button disabled type="button">إرسال</button>
          </form>
          <p className="helper">المساعد غير متصل بذكاء اصطناعي أو قاعدة بيانات في هذه النسخة. لن ينفّذ أوامر فعلية.</p>
        </section>

        <footer><span>© AL-ZOOL AZ ERP</span><span>بناء أولي · متعدد الشركات مخطط له</span></footer>
      </section>
    </main>
  );
}
