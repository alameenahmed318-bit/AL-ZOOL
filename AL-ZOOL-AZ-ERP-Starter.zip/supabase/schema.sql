-- AL-ZOOL AZ ERP: initial multi-tenant schema.
-- Run in a NEW Supabase project after reviewing it.
-- Row Level Security is enabled. Do not expose service_role keys in the browser.

create extension if not exists pgcrypto;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  currency text not null default 'AED',
  created_at timestamptz not null default now()
);

create table if not exists public.company_members (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','accountant','sales','member')),
  created_at timestamptz not null default now(),
  primary key (company_id, user_id)
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  invoice_number text not null,
  status text not null default 'draft' check (status in ('draft','sent','paid','overdue','cancelled')),
  currency text not null default 'AED',
  total numeric(12,2) not null default 0 check (total >= 0),
  due_date date,
  created_at timestamptz not null default now(),
  unique (company_id, invoice_number)
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  description text not null,
  category text,
  amount numeric(12,2) not null check (amount >= 0),
  currency text not null default 'AED',
  expense_date date not null default current_date,
  created_at timestamptz not null default now()
);

create index if not exists customers_company_id_idx on public.customers(company_id);
create index if not exists invoices_company_id_idx on public.invoices(company_id);
create index if not exists expenses_company_id_idx on public.expenses(company_id);

create or replace function public.is_company_member(target_company uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.company_members m
    where m.company_id = target_company and m.user_id = auth.uid()
  );
$$;

revoke all on function public.is_company_member(uuid) from public;
grant execute on function public.is_company_member(uuid) to authenticated;

alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.customers enable row level security;
alter table public.invoices enable row level security;
alter table public.expenses enable row level security;

create policy "members can view their companies"
on public.companies for select to authenticated
using (public.is_company_member(id));

create policy "members can view company membership"
on public.company_members for select to authenticated
using (public.is_company_member(company_id));

create policy "members can read customers"
on public.customers for select to authenticated
using (public.is_company_member(company_id));
create policy "authorized members can add customers"
on public.customers for insert to authenticated
with check (
  public.is_company_member(company_id)
  and exists (
    select 1 from public.company_members m
    where m.company_id = customers.company_id
      and m.user_id = auth.uid()
      and m.role in ('owner','admin','sales')
  )
);
create policy "authorized members can update customers"
on public.customers for update to authenticated
using (
  exists (select 1 from public.company_members m
    where m.company_id = customers.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin','sales'))
)
with check (public.is_company_member(company_id));
create policy "admins can delete customers"
on public.customers for delete to authenticated
using (
  exists (select 1 from public.company_members m
    where m.company_id = customers.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin'))
);

create policy "members can read invoices"
on public.invoices for select to authenticated
using (public.is_company_member(company_id));
create policy "authorized members can add invoices"
on public.invoices for insert to authenticated
with check (
  exists (select 1 from public.company_members m
    where m.company_id = invoices.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin','accountant','sales'))
);
create policy "authorized members can update invoices"
on public.invoices for update to authenticated
using (
  exists (select 1 from public.company_members m
    where m.company_id = invoices.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin','accountant','sales'))
)
with check (public.is_company_member(company_id));
create policy "admins can delete invoices"
on public.invoices for delete to authenticated
using (
  exists (select 1 from public.company_members m
    where m.company_id = invoices.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin'))
);

create policy "members can read expenses"
on public.expenses for select to authenticated
using (public.is_company_member(company_id));
create policy "authorized members can add expenses"
on public.expenses for insert to authenticated
with check (
  exists (select 1 from public.company_members m
    where m.company_id = expenses.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin','accountant'))
);
create policy "authorized members can update expenses"
on public.expenses for update to authenticated
using (
  exists (select 1 from public.company_members m
    where m.company_id = expenses.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin','accountant'))
)
with check (public.is_company_member(company_id));
create policy "admins can delete expenses"
on public.expenses for delete to authenticated
using (
  exists (select 1 from public.company_members m
    where m.company_id = expenses.company_id and m.user_id = auth.uid()
      and m.role in ('owner','admin'))
);

-- Security note:
-- Provisioning a company and its first owner should happen in a trusted server-side
-- onboarding flow or controlled SQL admin process, never from an unrestricted client.
-- Add audit logs, rate limits, backups, and a reviewed onboarding flow before production.
